<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { useGameStore } from '@/stores/gameStore'
import { usePlayerStore } from '@/stores/playerStore'
import { useLobbyStore } from '@/stores/lobbyStore'
import { useLeaderboardStore } from '@/stores/leaderboardStore'
import { useHistoryStore } from '@/stores/historyStore'
import * as gameService from '@/services/gameService'

const gameStore = useGameStore()
const playerStore = usePlayerStore()
const lobbyStore = useLobbyStore()
const leaderboardStore = useLeaderboardStore()
const historyStore = useHistoryStore()

const betAmountInput = ref(100)
const isPlacingBet = ref(false)
const isCashingOut = ref(false)
const mode = ref<'manual' | 'auto'>('manual')
const autoCashOutTarget = ref(2)
const activeTab = ref<'live' | 'mine' | 'top'>('live')

const potentialPayout = computed(() =>
  gameStore.myBetAmount ? (gameStore.myBetAmount * gameStore.currentMultiplier).toFixed(2) : '0.00'
)
const liveProfit = computed(() =>
  gameStore.myBetAmount ? (gameStore.myBetAmount * gameStore.currentMultiplier - gameStore.myBetAmount).toFixed(2) : '0.00'
)

const displayMultiplier = computed(() => `${gameStore.currentMultiplier.toFixed(2)}x`)

const phaseLabel = computed(() => {
  switch (gameStore.phase) {
    case 'Waiting':
      return `Next round starts in ${gameStore.countdownSeconds ?? '…'}s`
    case 'Running':
      return 'Round in progress'
    case 'Crashed':
      return 'Flew away!'
    default:
      return 'Connecting…'
  }
})

const canPlaceBet = computed(
  () => gameStore.phase === 'Waiting' && gameStore.myBetStatus !== 'Placed'
)
const hasLiveBet = computed(
  () => gameStore.myBetStatus === 'Placed' && gameStore.phase === 'Running'
)

async function handlePlaceBet() {
  isPlacingBet.value = true
  try {
    await gameService.placeBet(betAmountInput.value)
  } finally {
    isPlacingBet.value = false
  }
}

async function handleCashOut() {
  if (isCashingOut.value) return
  isCashingOut.value = true
  try {
    await gameService.cashOut()
  } finally {
    isCashingOut.value = false
  }
}

watch(() => gameStore.currentMultiplier, (m) => {
  if (
    mode.value === 'auto' &&
    gameStore.phase === 'Running' &&
    gameStore.myBetStatus === 'Placed' &&
    gameStore.cashOutStatus !== 'CashedOut' &&
    !isCashingOut.value &&
    m >= autoCashOutTarget.value
  ) {
    handleCashOut()
  }
})

// --- Flight curve ------------------------------------------------------
type Sample = { t: number; m: number }
const samples = ref<Sample[]>([{ t: 0, m: 1 }])
const maxT = ref(10)
const maxM = ref(2)
let startTime = performance.now()
let displayedM = 1
let intervalId: ReturnType<typeof setInterval> | null = null

function resetCurve(startMultiplier: number) {
  samples.value = [{ t: 0, m: startMultiplier }]
  maxT.value = 10
  maxM.value = Math.max(2, startMultiplier * 1.2)
  startTime = performance.now()
  displayedM = startMultiplier
}

function stepCurve() {
  if (gameStore.phase !== 'Running') return
  const t = (performance.now() - startTime) / 1000
  const target = gameStore.currentMultiplier
  // Ease toward the latest server tick instead of holding it flat between ticks —
  // keeps the line moving smoothly even when ticks arrive sparsely.
  displayedM = Math.min(target, displayedM + (target - displayedM) * 0.25)
  samples.value = [...samples.value, { t, m: displayedM }].slice(-260)
  if (t > maxT.value * 0.9) maxT.value = t / 0.85
  if (target > maxM.value * 0.9) maxM.value = target / 0.65
}

watch(() => gameStore.phase, (phase, prev) => {
  if (phase === 'Running' && prev !== 'Running') resetCurve(1)
  if (phase === 'Waiting') resetCurve(1)
})

const points = computed(() =>
  samples.value.map((s) => ({
    x: (s.t / maxT.value) * 1000,
    y: 480 - ((s.m - 1) / (maxM.value - 1)) * 360,
  }))
)

const linePath = computed(() =>
  points.value.length ? points.value.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ') : ''
)

const areaPath = computed(() => {
  const pts = points.value
  const last = pts.at(-1)
  if (!last) return ''
  return `M0,500 L${pts.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' L')} L${last.x.toFixed(1)},500 Z`
})

const planePos = computed(() => {
  const pts = points.value
  const last = pts.at(-1)
  if (gameStore.phase === 'Waiting' || !last) {
    return { leftPct: 2, topPct: 94, angle: -12 }
  }
  const prev = (pts.length > 5 ? pts.at(-6) : pts.at(0)) ?? last
  const dx = last.x - prev.x || 1
  const dy = last.y - prev.y
  let angle = Math.atan2(dy, dx) * (180 / Math.PI)
  angle = Math.max(-70, Math.min(5, angle))
  return { leftPct: last.x / 10, topPct: last.y / 5, angle }
})

onMounted(() => {
  if (gameStore.phase === 'Running') resetCurve(gameStore.currentMultiplier)
  intervalId = setInterval(stepCurve, 50)
  lobbyStore.fetchOnlinePlayers()
  leaderboardStore.fetchLeaderboard()
  historyStore.fetchBets()
})
onUnmounted(() => {
  if (intervalId) clearInterval(intervalId)
})

// --- Leaderboard panel --------------------------------------------------
const CASHOUT_RE = /^(.*) \(cashed out ([\d.]+)x\)$/

const liveBets = computed(() =>
  [...gameStore.roundBets].reverse().map((b) => {
    const match = CASHOUT_RE.exec(b.username)
    if (match) {
      return { key: b.playerId + b.username, username: match[1], mult: `${Number(match[2]).toFixed(2)}x`, cash: b.amount.toFixed(2), cashedOut: true }
    }
    return { key: b.playerId + b.username, username: b.username, mult: '-', cash: 'Pending', cashedOut: false }
  })
)

const totalBetAmount = computed(() =>
  gameStore.roundBets.filter((b) => !CASHOUT_RE.test(b.username)).reduce((sum, b) => sum + b.amount, 0)
)
const activeBetsCount = computed(
  () => gameStore.roundBets.filter((b) => !CASHOUT_RE.test(b.username)).length
)

function historyChipClass(v: number) {
  if (v >= 10) return 'bg-gold-500/15 text-gold-300 border-gold-500/40'
  if (v >= 2) return 'bg-aviator-600/25 text-rose-100 border-aviator-500/40'
  return 'bg-aviator-950/70 text-rose-300/50 border-aviator-800'
}
</script>

<template>
  <div class="min-h-screen bg-gradient-to-b from-aviator-950 via-aviator-900 to-aviator-950 text-rose-50 flex flex-col">
    <!-- History ticker -->
    <div class="flex items-center gap-3 px-4 py-2 border-b border-gold-600/15 overflow-x-auto">
      <span class="text-xs uppercase tracking-wider text-rose-300/50 shrink-0">History</span>
      <div class="flex gap-2 shrink-0">
        <span
          v-for="(p, i) in gameStore.lastCrashPoints"
          :key="i"
          class="px-2.5 py-1 rounded-md text-xs font-semibold border"
          :class="historyChipClass(p)"
        >
          {{ p.toFixed(2) }}x
        </span>
        <span v-if="gameStore.lastCrashPoints.length === 0" class="text-xs text-rose-300/40">No rounds yet</span>
      </div>
      <span class="ml-auto text-xs text-rose-300/50 shrink-0">Round #{{ gameStore.roundNumber ?? '—' }}</span>
    </div>

    <div class="flex flex-col lg:flex-row gap-4 p-4 flex-1">
      <!-- Leaderboard panel -->
      <div class="w-full lg:w-72 order-2 lg:order-1 bg-aviator-900/60 border border-gold-600/15 rounded-xl p-3 flex flex-col">
        <div class="flex items-center justify-between mb-3">
          <h2 class="text-gold-300 font-bold tracking-wide text-sm">LEADERBOARD</h2>
          <span class="text-xs text-rose-300/50 flex items-center gap-1">
            <span class="h-1.5 w-1.5 rounded-full bg-emerald-400 inline-block"></span>
            {{ lobbyStore.onlinePlayers.length }} Online
          </span>
        </div>

        <div
          v-if="leaderboardStore.data?.biggestWins?.[0]"
          class="rounded-lg border border-gold-500/30 bg-gold-500/10 px-3 py-2 mb-3 text-xs"
        >
          <p class="text-gold-300 font-bold">🏆 BIG WIN</p>
          <p class="text-rose-100/80">
            {{ leaderboardStore.data.biggestWins[0].username }} won
            {{ leaderboardStore.data.biggestWins[0].payout }} credits!
          </p>
        </div>

        <div class="flex text-xs border-b border-gold-600/15 mb-2">
          <button
            class="px-2 py-1.5 -mb-px border-b-2 transition"
            :class="activeTab === 'live' ? 'border-gold-400 text-gold-300' : 'border-transparent text-rose-300/50 hover:text-rose-200'"
            @click="activeTab = 'live'"
          >
            Live Bets
          </button>
          <button
            class="px-2 py-1.5 -mb-px border-b-2 transition"
            :class="activeTab === 'mine' ? 'border-gold-400 text-gold-300' : 'border-transparent text-rose-300/50 hover:text-rose-200'"
            @click="activeTab = 'mine'"
          >
            My Bets
          </button>
          <button
            class="px-2 py-1.5 -mb-px border-b-2 transition"
            :class="activeTab === 'top' ? 'border-gold-400 text-gold-300' : 'border-transparent text-rose-300/50 hover:text-rose-200'"
            @click="activeTab = 'top'"
          >
            Top
          </button>
        </div>

        <div class="flex-1 overflow-y-auto max-h-80 lg:max-h-none">
          <!-- Live bets -->
          <div v-if="activeTab === 'live'">
            <div class="grid grid-cols-3 text-[11px] text-rose-300/40 px-1 pb-1">
              <span>User</span><span class="text-right">Mult</span><span class="text-right">Cash</span>
            </div>
            <div
              v-for="b in liveBets"
              :key="b.key"
              class="grid grid-cols-3 text-xs px-1 py-1.5 rounded hover:bg-aviator-850/50"
            >
              <span class="truncate text-rose-100/80">{{ b.username }}</span>
              <span class="text-right text-rose-300/60">{{ b.mult }}</span>
              <span class="text-right" :class="b.cashedOut ? 'text-emerald-400 font-semibold' : 'text-rose-300/40 italic'">{{ b.cash }}</span>
            </div>
            <p v-if="liveBets.length === 0" class="text-xs text-rose-300/40 px-1 py-2">No bets placed yet this round.</p>
          </div>

          <!-- My bets -->
          <div v-else-if="activeTab === 'mine'">
            <div
              v-for="b in historyStore.bets"
              :key="b.betId"
              class="grid grid-cols-3 text-xs px-1 py-1.5 rounded hover:bg-aviator-850/50"
            >
              <span class="text-rose-100/80">#{{ b.roundNumber }}</span>
              <span class="text-right text-rose-300/60">{{ b.amount }}</span>
              <span class="text-right" :class="b.payout ? 'text-emerald-400 font-semibold' : 'text-rose-300/40 italic'">
                {{ b.payout ?? b.status }}
              </span>
            </div>
            <p v-if="historyStore.bets.length === 0" class="text-xs text-rose-300/40 px-1 py-2">You haven't placed any bets yet.</p>
          </div>

          <!-- Top -->
          <div v-else>
            <p class="text-[11px] uppercase text-rose-300/40 px-1 pb-1">Biggest Wins</p>
            <div
              v-for="(e, i) in leaderboardStore.data?.biggestWins ?? []"
              :key="'w' + i"
              class="grid grid-cols-3 text-xs px-1 py-1.5 rounded hover:bg-aviator-850/50"
            >
              <span class="truncate text-rose-100/80">{{ i + 1 }}. {{ e.username }}</span>
              <span class="text-right text-rose-300/60">{{ e.cashOutMultiplier.toFixed(2) }}x</span>
              <span class="text-right text-emerald-400 font-semibold">{{ e.payout }}</span>
            </div>
            <p class="text-[11px] uppercase text-rose-300/40 px-1 pb-1 pt-3">Best Multipliers</p>
            <div
              v-for="(e, i) in leaderboardStore.data?.bestMultipliers ?? []"
              :key="'m' + i"
              class="grid grid-cols-2 text-xs px-1 py-1.5 rounded hover:bg-aviator-850/50"
            >
              <span class="truncate text-rose-100/80">{{ i + 1 }}. {{ e.username }}</span>
              <span class="text-right text-gold-300 font-semibold">{{ e.cashOutMultiplier.toFixed(2) }}x</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Main stage -->
      <div
        class="flex-1 order-1 lg:order-2 relative rounded-xl border border-gold-600/15 overflow-hidden min-h-[420px] bg-aviator-950 flight-grid"
      >
        <svg viewBox="0 0 1000 500" preserveAspectRatio="none" class="absolute inset-0 w-full h-full">
          <defs>
            <linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#c9282b" stop-opacity="0.45" />
              <stop offset="100%" stop-color="#150406" stop-opacity="0" />
            </linearGradient>
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>
          <path :d="areaPath" fill="url(#areaFill)" />
          <path
            :d="linePath"
            fill="none"
            :stroke="gameStore.phase === 'Crashed' ? '#7a1417' : '#e8353a'"
            stroke-width="6"
            stroke-linecap="round"
            filter="url(#glow)"
          />
        </svg>

        <!-- Plane -->
        <div
          class="absolute h-11 w-11 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center rounded-full transition-[left,top] duration-75 ease-linear"
          :class="[
            gameStore.phase === 'Waiting' ? 'plane-idle' : '',
            gameStore.phase === 'Crashed' ? 'bg-aviator-700/60 shadow-[0_0_25px_rgba(122,20,23,0.7)]' : 'bg-aviator-500 shadow-[0_0_25px_rgba(232,53,58,0.8)]',
          ]"
          :style="{ left: planePos.leftPct + '%', top: planePos.topPct + '%' }"
        >
          <svg
            viewBox="0 0 24 24"
            class="h-6 w-6"
            :class="gameStore.phase === 'Crashed' ? 'text-rose-300/70' : 'text-white'"
            :style="{ transform: `rotate(${planePos.angle}deg)` }"
            fill="currentColor"
          >
            <path d="M21 12l-8-2-1-7-2 1v6l-8 2v2l8-1v5l-3 2v1l4-1 4 1v-1l-3-2v-5l8 1z" />
          </svg>
        </div>

        <!-- Multiplier readout -->
        <div class="absolute inset-x-0 top-10 flex flex-col items-center gap-2 pointer-events-none">
          <p
            class="text-5xl sm:text-6xl font-black tabular-nums"
            :class="gameStore.phase === 'Crashed' ? 'text-aviator-400' : 'text-white'"
            style="text-shadow: 0 0 30px rgba(232,53,58,0.55)"
          >
            {{ displayMultiplier }}
          </p>
          <span
            v-if="gameStore.phase === 'Running'"
            class="px-3 py-1 rounded-full bg-black/30 border border-gold-500/30 text-[11px] tracking-wider text-gold-300 flex items-center gap-1.5"
          >
            <span class="h-1.5 w-1.5 rounded-full bg-emerald-400 pulse-dot"></span>
            LIVE PULSE
          </span>
          <span v-if="gameStore.phase === 'Crashed'" class="text-aviator-400 font-bold text-lg crash-flash">
            FLEW AWAY!
          </span>
          <p class="text-rose-200/70 text-sm">{{ phaseLabel }}</p>
        </div>
      </div>
    </div>

    <!-- Bet panel -->
    <div class="flex flex-col sm:flex-row gap-3 px-4 pb-3">
      <div class="flex-1 bg-aviator-900/60 border border-gold-600/15 rounded-xl p-4">
        <div class="flex items-center justify-between mb-3">
          <span class="text-xs uppercase tracking-wider text-rose-300/50">Bet Amount <span class="text-rose-300/30">ZAR</span></span>
          <div class="flex gap-1 bg-aviator-950 rounded-md p-1 text-xs font-semibold">
            <button
              class="px-3 py-1 rounded transition"
              :class="mode === 'manual' ? 'bg-aviator-500 text-white' : 'text-rose-300/50 hover:text-rose-200'"
              @click="mode = 'manual'"
            >
              MANUAL
            </button>
            <button
              class="px-3 py-1 rounded transition"
              :class="mode === 'auto' ? 'bg-aviator-500 text-white' : 'text-rose-300/50 hover:text-rose-200'"
              @click="mode = 'auto'"
            >
              AUTO
            </button>
          </div>
        </div>

        <div class="flex flex-col sm:flex-row gap-2">
          <input
            v-model.number="betAmountInput"
            type="number"
            min="1"
            :max="playerStore.profile?.creditBalance ?? undefined"
            class="flex-1 min-w-0 rounded-md bg-aviator-950 border border-gold-600/20 px-3 py-2 text-rose-50 focus:outline-none focus:ring-2 focus:ring-gold-500/50"
          />
          <button
            @click="handlePlaceBet"
            :disabled="!canPlaceBet || isPlacingBet"
            class="w-full sm:w-auto rounded-md bg-aviator-500 hover:bg-aviator-400 disabled:opacity-40 px-5 py-2 font-bold transition shadow-[0_0_14px_rgba(156,28,31,0.5)]"
          >
            {{ isPlacingBet ? 'Placing…' : 'Place Bet' }}
          </button>
        </div>

        <div v-if="mode === 'auto'" class="flex items-center gap-2 mt-3 text-sm">
          <span class="text-rose-300/60">Auto cash out at</span>
          <input
            v-model.number="autoCashOutTarget"
            type="number"
            min="1.01"
            step="0.1"
            class="w-20 rounded-md bg-aviator-950 border border-gold-600/20 px-2 py-1 text-rose-50 focus:outline-none focus:ring-2 focus:ring-gold-500/50"
          />
          <span class="text-rose-300/60">x</span>
        </div>

        <p v-if="gameStore.myBetStatus === 'Rejected'" class="text-sm text-aviator-400 mt-2">
          {{ gameStore.betRejectionReason }}
        </p>
        <p v-if="gameStore.phase !== 'Waiting'" class="text-xs text-rose-300/40 mt-2">
          Betting opens when the next round starts waiting.
        </p>
      </div>

      <div class="flex-1 bg-aviator-900/60 border border-gold-600/15 rounded-xl p-4 flex flex-col justify-center">
        <template v-if="hasLiveBet">
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <span class="h-1.5 w-1.5 rounded-full bg-emerald-400 pulse-dot"></span>
              Live Bet Active
            </span>
            <span class="text-emerald-400 font-semibold text-sm">Profit: +{{ liveProfit }}</span>
          </div>
          <button
            @click="handleCashOut"
            :disabled="isCashingOut"
            class="w-full rounded-md bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 py-2 font-bold transition"
          >
            {{ isCashingOut ? 'Cashing out…' : `Cash Out (${potentialPayout})` }}
          </button>
        </template>

        <template v-else-if="gameStore.myBetStatus === 'Placed'">
          <p class="text-emerald-400 text-sm text-center">
            Bet placed: {{ gameStore.myBetAmount }} credits — waiting for takeoff
          </p>
        </template>

        <template v-else-if="gameStore.cashOutStatus === 'CashedOut' && gameStore.cashOutResult">
          <p class="text-emerald-400 text-sm text-center">
            Cashed out at {{ gameStore.cashOutResult.cashOutMultiplier.toFixed(2) }}x for {{ gameStore.cashOutResult.payout }} credits!
          </p>
        </template>

        <template v-else-if="gameStore.cashOutStatus === 'Rejected'">
          <p class="text-sm text-aviator-400 text-center">{{ gameStore.cashOutRejectionReason }}</p>
        </template>

        <template v-else>
          <p class="text-sm text-rose-300/40 text-center">Place a bet before the round takes off.</p>
        </template>
      </div>
    </div>

    <!-- Footer stats -->
    <div class="flex items-center justify-between px-4 pb-3 text-xs text-rose-300/40">
      <span>Total Bets: {{ totalBetAmount.toFixed(2) }}</span>
      <span>Active: {{ activeBetsCount }}</span>
    </div>
  </div>
</template>

<style scoped>
.flight-grid {
  background-image:
    linear-gradient(rgba(240, 193, 75, 0.06) 1px, transparent 1px),
    linear-gradient(90deg, rgba(240, 193, 75, 0.06) 1px, transparent 1px);
  background-size: 40px 40px;
}

.pulse-dot {
  animation: pulse-dot 1.4s ease-in-out infinite;
}
@keyframes pulse-dot {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.4; transform: scale(0.7); }
}

.plane-idle {
  animation: plane-bob 1.8s ease-in-out infinite;
}
@keyframes plane-bob {
  0%, 100% { transform: translate(-50%, -50%) translateY(0); }
  50% { transform: translate(-50%, -50%) translateY(-6px); }
}

.crash-flash {
  animation: crash-flash 0.6s ease-in-out infinite;
}
@keyframes crash-flash {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.35; }
}
</style>
